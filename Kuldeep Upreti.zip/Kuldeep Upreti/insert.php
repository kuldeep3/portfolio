<?php
$host = "localhost";
$userName = "root";
$password = "";
$dbName = "info";

$conn = new mysqli($host, $userName, $password, $dbName);

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$Name = $_POST['Name'];
$Email = $_POST['Email'];
$Subject = $_POST['Subject'];
$Message = $_POST['Message'];

$sql = "INSERT INTO contact (Name,Email,Subject,Message) VALUES ('$Name','$Email','$Subject','$Message')";

if(!mysqli_query($conn,$sql));
{
	echo "Not Inserted";
}
else
{
	echo "Inserted";
}

header("refresh:2; url=index.html");
?>